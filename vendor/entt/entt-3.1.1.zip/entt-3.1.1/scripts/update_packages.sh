#!/bin/sh

scripts/update_homebrew.sh $1
